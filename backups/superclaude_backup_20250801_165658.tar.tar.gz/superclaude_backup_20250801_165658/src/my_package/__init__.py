def hello() -> str:
    return "Hello from Python-Project-Template!"
