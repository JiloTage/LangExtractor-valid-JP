from my_package import hello


def main() -> None:
    print(hello())


if __name__ == "__main__":
    main()
